package modelo;

import java.util.ArrayList;
import java.util.List;

public class Genero {
	private String nome;
	private List<Video> listaDeVideos = new ArrayList<>();
	
	public Genero(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public List<Video> getListaDeVideo(){
		return listaDeVideos;
	}
	
	public void adicionarVideo(Video video) {
		video.setGenero(this);
        this.listaDeVideos.add(video);
    }


	public void removerVideo(Video video) {
		video.setGenero(null);
        this.listaDeVideos.remove(video);
    }
	
	public void setListaDevideo(List<Video> listaDeVideo) {
		this.listaDeVideos = listaDeVideo;
	}
	
	public Video localizarVideo(String titulo) {
	    for (Video video : listaDeVideos) {
	        if (video.getTitulo().equals(titulo)) {
	            return video;
	        }
	    }
	    return null;
	}
	
	 @Override
		public String toString() {
		 
		    String texto = "";
		    for(Video v : listaDeVideos)
		    	texto = texto + v.getTitulo() + ",  ";
		    
			return "Genero [nome=" + nome + ", listaDeVideos="  + texto  + "]";
		}
}

