package regras_negocio;
/**********************************
 * IFPB - Curso Superior de Tec. em Sist. para Internet
 * POB - Persistencia de Objetos
 * Prof. Fausto Ayres
 *
 */

import java.util.List;

import daodb4o.DAO;
import daodb4o.DAOGenero;
import daodb4o.DAOUsuario;
import daodb4o.DAOVideo;
import modelo.Genero;
import modelo.Usuario;
import modelo.Video;

public class Fachada {
	private Fachada() {}
	
	private static DAOVideo daovideo = new DAOVideo();
	private static DAOGenero daogenero = new DAOGenero();
	private static DAOUsuario daousuario = new DAOUsuario(); 
	public static Usuario logado;	//contem o objeto Usuario logado em TelaLogin.java

	public static void inicializar(){
		DAO.open();
	}
	public static void finalizar(){
		DAO.close();
	}


	public static Video cadastrarVideo(String titulo, String link, double classificacao, String nome) throws Exception{
		DAO.begin();
		Video video = daovideo.read(titulo);
		if (video!=null)
			throw new Exception("Video ja foi cadastrado:" + titulo);
		
		Genero genero = daogenero.read(nome);
		if (genero==null)
			throw new Exception("Genero não foi cadastrado:" + nome);
		
		video = new Video(titulo, link, classificacao, genero);
		
		daovideo.create(video);
		DAO.commit();
		return video;
	}
	
	public static Genero cadastrarGenero(String nome) throws Exception {
		DAO.begin();
		Genero genero = daogenero.read(nome);
		if (genero!=null)
			throw new Exception("Genero ja foi cadastrado:" + nome);
		
		genero = new Genero(nome);
		daogenero.create(genero);
		DAO.commit();
		return genero;
	}

	public static void alterarVideo(String titulo,String nome) throws Exception{
		DAO.begin();
		Video vide =  daovideo.read(titulo);
		if(vide==null) 
			throw new Exception ("Video nao encontrado");

		Genero genero = daogenero.read(nome);
		if (genero==null)
			throw new Exception("Genero não foi cadastrado:" + nome);

		
		Genero generoAntigo = vide.getGenero();
		vide.setGenero(genero);
		genero.adicionarVideo(vide);
		generoAntigo.removerVideo(vide);

		daovideo.update(vide);
		daogenero.update(genero);
		DAO.commit();
	}
	
	public static void excluirVideo(int id) throws Exception{
		DAO.begin();
		Video vide =  daovideo.read(id);
		if(vide==null) 
			throw new Exception ("carro incorreto para exclusao " + id);

		Genero generoAntigo = vide.getGenero();
		generoAntigo.removerVideo(vide);
		
		daovideo.delete(vide);
		DAO.commit();
	}
	
	public static List<Video>  listarVideo(){
		DAO.begin();
		List<Video> resultados =  daovideo.readAll();
		DAO.commit();
		return resultados;
	} 

	public static List<Genero>  listarGenero(){
		DAO.begin();
		List<Genero> resultados =  daogenero.readAll();
		DAO.commit();
		return resultados;
	}

	public static List<Usuario>  listarUsuarios(){
		DAO.begin();
		List<Usuario> resultados =  daousuario.readAll();
		DAO.commit();
		return resultados;
	} 

	public static Video localizarVideo(String titulo){
		return daovideo.read(titulo);
	}
	public static Genero localizarGenero(String nome){
		return daogenero.read(nome);
	}

	//------------------Usuario------------------------------------
	public static Usuario cadastrarUsuario(String nome, String senha) throws Exception{
		DAO.begin();
		Usuario usu = daousuario.read(nome);
		if (usu!=null)
			throw new Exception("Usuario ja cadastrado:" + nome);
		usu = new Usuario(nome, senha);

		daousuario.create(usu);
		DAO.commit();
		return usu;
	}
	public static Usuario localizarUsuario(String nome, String senha) {
		Usuario usu = daousuario.read(nome);
		if (usu==null)
			return null;
		if (! usu.getSenha().equals(senha))
			return null;
		return usu;
	}
}
