/**********************************
 * IFPB - Curso Superior de Tec. em Sist. para Internet
 * POB - Persistencia de Objetos
 * Prof. Fausto Ayres
 *
 */

package appconsole;

import regras_negocio.Fachada;

public class Cadastrar {

	public Cadastrar() {
		
		try {
			Fachada.inicializar();
			System.out.println("cadastrando genero...");
			Fachada.cadastrarGenero("acao");
			Fachada.cadastrarGenero("comedia");
			Fachada.cadastrarGenero("drama");
			Fachada.cadastrarGenero("terror");
			Fachada.cadastrarGenero("guerra");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		try {
			System.out.println("cadastrando filme...");
			Fachada.cadastrarVideo("VF10", "https://netflix.com/video1", 4.5, "acao");
			Fachada.cadastrarVideo("Mr Bean", "https://netflix.com/video2", 4.8, "comedia");
			Fachada.cadastrarVideo("O Acordo", "https://primevideo.com/video3", 3.1, "drama");
			Fachada.cadastrarVideo("Megan", "https://primevideo.com/video4", 4.0, "terror");
			Fachada.cadastrarVideo("Narvik", "https://www.com/video5", 4.1, "guerra");
			Fachada.cadastrarVideo("Vingadores", "https://www.starplus.com/Vingadores ", 4.9, "acao");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		Fachada.finalizar();
		System.out.println("\nfim do programa !");
	}


	public static void main(String[] args) {
		new Cadastrar();
	}
}
