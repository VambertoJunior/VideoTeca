package daodb4o;

import java.util.List;

import com.db4o.query.Candidate;
import com.db4o.query.Evaluation;
import com.db4o.query.Query;

import modelo.Genero;
import modelo.Video;

public class DAOVideo extends DAO<Video> {

	public Video read(Object chave) {
		String titulo = (String) chave;
		Query q = manager.query();
		q.constrain(Video.class);
		q.descend("titulo").constrain(titulo);
		List<Video> resultados = q.execute();
		if (resultados.size() > 0)
			return resultados.get(0);
		else
			return null;
	}

	public void create(Video obj) {
		int novoid = super.gerarId(); // gerar novo id da classe
		obj.setId(novoid); // atualizar id do objeto antes de grava-lo no banco
		manager.store(obj);
	}

	
	public List<Video> videoClassificacao (int classificacao){
		Query q = manager.query();
		q.constrain(Video.class);
		q.descend("classificacao").constrain(classificacao);
		List<Video> resultados = q.execute();
		return resultados;
	}
	
	public List<Video> generoNome(String nome) {
		// Quais os videos do genero de nome X:
		Query q1 = manager.query();
		q1.constrain(Video.class);
		q1.descend("genero").descend(nome).orderAscending();
		List<Video> resultados = q1.execute();
		return resultados;
	}
}
