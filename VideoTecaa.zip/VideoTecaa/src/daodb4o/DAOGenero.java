package daodb4o;

import java.util.List;

import com.db4o.query.Candidate;
import com.db4o.query.Evaluation;
import com.db4o.query.Query;

import modelo.Genero;
import modelo.Video;

public class DAOGenero extends DAO<Genero> {

	public Genero read(Object chave) {
		String nome = (String) chave;
		Query q = manager.query();
		q.constrain(Genero.class);
		q.descend("nome").constrain(nome);
		List<Genero> resultados = q.execute();
		if (resultados.size() > 0)
			return resultados.get(0);
		else
			return null;
	}

	public List<Genero> generoMais(String mais) {
		// quais os generos que tem mais de N videos:
		Query q2 = manager.query();
		q2.constrain(Genero.class);
		q2.constrain(new Filtro());
		List<Genero> resultados = q2.execute();
		return resultados;

	}
}

class Filtro implements Evaluation {
	public void evaluate(Candidate candidate) {
		Genero g = (Genero) candidate.getObject();
		if (g.getListaDeVideo().size() == 1)
			candidate.include(true); // incluir objeto no resultado da consulta
		else
			candidate.include(false); // excluir objeto do resultado da consulta
	}
}